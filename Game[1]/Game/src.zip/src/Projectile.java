import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;

public class Projectile {
    private double x, y;
    private double speed;
    private double damage;
    private int direction;
    private Circle sprite;
    public Projectile(double x, double y, double speed, double damage, int direction) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.damage = damage;
        this.direction = direction;
        this.sprite = new Circle(x, y, 5, Color.BLACK);
    }

    public double getX() {

        return x;
    }

    public void setX(double x) {

        this.x = x;
    }

    public double getY() {

        return y;
    }

    public void setY(double y) {

        this.y = y;
    }

    public double getSpeed() {

        return speed;
    }

    public void setSpeed(double speed) {

        this.speed = speed;
    }

    public double getDamage() {

        return damage;
    }

    public void setDamage(double damage) {

        this.damage = damage;
    }

    public int getDirection() {

        return direction;
    }

    public void setDirection(int direction) {

        this.direction = direction;
    }
    public void move() {
        this.sprite.setCenterX(this.sprite.getCenterX() + (speed * direction));
    }

    public Circle getSprite() {
        return sprite;
    }
}
