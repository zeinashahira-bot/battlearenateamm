import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class LavaThrower extends Weapons {

    public LavaThrower() {
        // Type, Damage, Cooldown (ms), Speed
        super("Lava Thrower", 25, 1200, 7.0);
    }

    @Override
    public Projectile shoot(double startX, double startY) {
        // Create the projectile
        Projectile p = new Projectile(startX, startY, projectilespeed, damage, 0);

        // Custom visual: Make the projectile Orange/Red to look like lava
        p.getSprite().setFill(Color.ORANGE);
        p.getSprite().setRadius(10); // Make it slightly bigger than normal bullets

        return p;
    }
}