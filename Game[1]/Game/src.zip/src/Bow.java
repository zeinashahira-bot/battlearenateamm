import javafx.scene.paint.Color;

public class Bow extends Weapons {

    public Bow() {
        // Type, Damage, Cooldown (ms), Speed
        // Bow deals 10 damage, fast 400ms cooldown, fast speed 12.0
        super("Bow", 10, 400, 12.0);
    }

    @Override
    public Projectile shoot(double startX, double startY) {
        Projectile p = new Projectile(startX, startY, projectilespeed, damage, 0);

        // Visual: Brown color to look like an arrow
        p.getSprite().setFill(Color.SADDLEBROWN);
        p.getSprite().setRadius(4); // Smaller arrow size

        return p;
    }
}