import javafx.scene.paint.Color;

public class Archer extends Character {
    // Constructor now requires x, y, and color so it can pass them to Character
    public Archer(int x, int y, Color color) {
        // Pass all 6 required arguments to the parent Character class
        super("Archer", 100, 100, x, y, color);
    }
}