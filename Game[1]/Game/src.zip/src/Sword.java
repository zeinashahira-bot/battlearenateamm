import javafx.scene.paint.Color;

public class Sword extends Weapons {

    public Sword() {
        // Type, Damage, Cooldown (ms), Speed
        // Sword deals 15 damage, 600ms cooldown, speed 9.0
        super("Sword", 15, 600, 9.0);
    }

    @Override
    public Projectile shoot(double startX, double startY) {
        // Create projectile
        Projectile p = new Projectile(startX, startY, projectilespeed, damage, 0);

        // Visual: Silver color to look like a sword beam
        p.getSprite().setFill(Color.SILVER);
        p.getSprite().setRadius(7);

        return p;
    }
}