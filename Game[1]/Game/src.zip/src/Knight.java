import javafx.scene.paint.Color;

public class Knight extends Character {

    // Constructor requires X, Y, and Color to place the knight on screen
    public Knight(int x, int y, Color color) {
        // Name, MaxHP, CurrentHP, X, Y, Color
        // Knights have higher HP (150)
        super("Knight", 150, 150, x, y, color);
    }
}