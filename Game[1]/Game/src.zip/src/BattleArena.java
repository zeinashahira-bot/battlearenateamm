import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BattleArena extends Application {

    private Pane gameRoot = new Pane();
    private Character player1;
    private Character player2;
    private List<Projectile> projectiles = new ArrayList<>();

    // Tracks currently pressed keys
    private Set<KeyCode> activeKeys = new HashSet<>();

    // UI Elements
    private ProgressBar p1HealthBar;
    private ProgressBar p2HealthBar;
    private Label winnerLabel;
    private AnimationTimer gameLoop;

    @Override
    public void start(Stage primaryStage) {
        // --- SCENE 1: MENU ---
        VBox menuBox = new VBox(20);
        menuBox.setAlignment(Pos.CENTER);
        Label title = new Label("BATTLE ARENA");
        title.setFont(new Font("Arial", 40));
        Button startBtn = new Button("START FIGHT");

        // FIX 1: Stop the button from keeping "focus" so keys work immediately
        startBtn.setFocusTraversable(false);

        menuBox.getChildren().addAll(title, startBtn);
        Scene menuScene = new Scene(menuBox, 800, 600);

        // --- SCENE 2: GAME ---
        setupGame();
        Scene gameScene = new Scene(gameRoot, 800, 600);

        // Input Handling
        gameScene.setOnKeyPressed(e -> activeKeys.add(e.getCode()));
        gameScene.setOnKeyReleased(e -> activeKeys.remove(e.getCode()));

        // Start Button Logic
        startBtn.setOnAction(e -> {
            primaryStage.setScene(gameScene);
            // FIX 2: Force the game to listen to the keyboard
            gameRoot.requestFocus();
            startGameLoop();
        });

        primaryStage.setTitle("JavaFX Battle Arena");
        primaryStage.setScene(menuScene);
        primaryStage.show();
    }

    private void setupGame() {
        gameRoot.setPrefSize(800, 600);

        // Divider Line
        Rectangle divider = new Rectangle(398, 0, 4, 600);
        divider.setFill(Color.GRAY);
        gameRoot.getChildren().add(divider);

        // --- SETUP PLAYERS ---
        // Player 1 (Blue) on Left
        player1 = new Character("Player 1", 100, 100, 100, 250, Color.BLUE);
        player1.setWeapon(new Bow());

        // Player 2 (Red) on Right - Fix position to be visible
        player2 = new Character("Player 2", 100, 100, 600, 250, Color.RED);
        player2.setWeapon(new Bow());

        // --- UI Layer ---
        HBox ui = new HBox(20);
        ui.setLayoutX(20);
        ui.setLayoutY(20);

        p1HealthBar = new ProgressBar(1.0);
        p1HealthBar.setStyle("-fx-accent: blue;");
        p2HealthBar = new ProgressBar(1.0);
        p2HealthBar.setStyle("-fx-accent: red;");

        ui.getChildren().addAll(new Label("P1:"), p1HealthBar, new Label("P2:"), p2HealthBar);

        // Winner Label
        winnerLabel = new Label("");
        winnerLabel.setFont(new Font("Arial", 50));
        winnerLabel.setLayoutX(200);
        winnerLabel.setLayoutY(250);

        // FIX 3: Ensure both players are added to the screen
        gameRoot.getChildren().addAll(player1.getSprite(), player2.getSprite(), ui, winnerLabel);
    }

    private void startGameLoop() {
        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };
        gameLoop.start();
    }

    private void update() {
        if (player1.isDead() || player2.isDead()) return;

        // --- MOVEMENT P1 (WASD) ---
        if (activeKeys.contains(KeyCode.W)) player1.move(0, -5);
        if (activeKeys.contains(KeyCode.S)) player1.move(0, 5);
        if (activeKeys.contains(KeyCode.A) && player1.getX() > 0) player1.move(-5, 0);
        if (activeKeys.contains(KeyCode.D) && player1.getX() < 360) player1.move(5, 0);

        // --- SHOOT P1 (Space) ---
        if (activeKeys.contains(KeyCode.SPACE)) {
            shoot(player1, 1); // 1 = Shoot Right
        }

        // --- MOVEMENT P2 (Arrows) ---
        if (activeKeys.contains(KeyCode.UP)) player2.move(0, -5);
        if (activeKeys.contains(KeyCode.DOWN)) player2.move(0, 5);
        if (activeKeys.contains(KeyCode.LEFT) && player2.getX() > 400) player2.move(-5, 0);
        if (activeKeys.contains(KeyCode.RIGHT) && player2.getX() < 760) player2.move(5, 0);

        // --- SHOOT P2 (Enter) ---
        if (activeKeys.contains(KeyCode.ENTER)) {
            shoot(player2, -1); // -1 = Shoot Left
        }

        updateProjectiles();
    }

    private void shoot(Character shooter, int direction) {
        if (shooter.getWeapon().canShoot()) {
            double startX = (direction == 1) ? shooter.getX() + 45 : shooter.getX() - 15;
            double startY = shooter.getY() + 30;

            // Create projectile
            Projectile p = shooter.getWeapon().shoot(startX, startY);
            p.setDirection(direction);

            projectiles.add(p);
            gameRoot.getChildren().add(p.getSprite());
        }
    }

    private void updateProjectiles() {
        List<Projectile> toRemove = new ArrayList<>();

        for (Projectile p : projectiles) {
            p.move();

            // Check Collisions
            if (p.getDirection() == 1) { // P1 shot checks P2 collision
                if (p.getSprite().getBoundsInParent().intersects(player2.getSprite().getBoundsInParent())) {
                    player2.takeDamage((int)p.getDamage());
                    toRemove.add(p);
                }
            } else { // P2 shot checks P1 collision
                if (p.getSprite().getBoundsInParent().intersects(player1.getSprite().getBoundsInParent())) {
                    player1.takeDamage((int)p.getDamage());
                    toRemove.add(p);
                }
            }

            // Remove if off screen
            if (p.getX() < 0 || p.getX() > 800) toRemove.add(p);
        }

        // Cleanup
        for (Projectile p : toRemove) {
            gameRoot.getChildren().remove(p.getSprite());
            projectiles.remove(p);
        }

        // Update UI
        p1HealthBar.setProgress((double)player1.getCurrenthealth() / player1.getMaxhealth());
        p2HealthBar.setProgress((double)player2.getCurrenthealth() / player2.getMaxhealth());

        checkWinner();
    }

    private void checkWinner() {
        if (player1.isDead()) {
            winnerLabel.setText("PLAYER 2 WINS!");
            winnerLabel.setTextFill(Color.RED);
            gameLoop.stop();
        } else if (player2.isDead()) {
            winnerLabel.setText("PLAYER 1 WINS!");
            winnerLabel.setTextFill(Color.BLUE);
            gameLoop.stop();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}