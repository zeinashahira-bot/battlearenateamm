public abstract class Weapons {
    protected String type;
    protected int damage;
    protected float cooldown;
    protected double projectilespeed;
    protected long lastShotTime = 0;

    public Weapons(String type, int damage, float cooldown, double projectilespeed) {
        this.type = type;
        this.damage = damage;
        this.cooldown = cooldown;
        this.projectilespeed = projectilespeed;
    }

    public boolean canShoot() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastShotTime >= cooldown) {
            lastShotTime = currentTime;
            return true;
        }
        return false;
    }

    public abstract Projectile shoot(double startX, double startY);

    public int getDamage() {
        return damage;
    }
    public double getProjectilespeed() {
        return projectilespeed;
    }
}