import javafx.scene.paint.Color;

public class FlameThrower extends Weapons {

    public FlameThrower() {
        // Type, Damage, Cooldown (ms), Speed
        super("FlameThrower", 50, 400, 2.0);
    }

    @Override
    public Projectile shoot(double startX, double startY) {
        // Create the projectile
        Projectile p = new Projectile(startX, startY, projectilespeed, damage, 0);

        // Custom visual: Orange fire
        p.getSprite().setFill(Color.ORANGE);
        p.getSprite().setRadius(8);

        return p;
    }
}