import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;
public class Character {
    private String name;
    private int Maxhealth;
    private int Currenthealth;
    private Rectangle sprite;
    private Weapons weapon;

    public Character(String name, int maxhealth,int x,int y, int currenthealth,Color color) {
        this.name = name;
        Maxhealth = maxhealth;
        Currenthealth = currenthealth;
        this.sprite = new Rectangle(x, y, 40, 60);
        this.sprite.setFill(color);
    }
    public double getX() {
        return sprite.getX();
    }
    public double getY() {
        return sprite.getY();
    }
    public Rectangle getSprite() {
        return sprite;
    }

    public void setWeapon(Weapons w) {
        this.weapon = w;
    }
    public Weapons getWeapon() {
        return weapon;
    }
    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public int getMaxhealth() {

        return Maxhealth;
    }

    public void setMaxhealth(int maxhealth) {

        Maxhealth = maxhealth;
    }

    public int getCurrenthealth() {

        return Currenthealth;
    }

    public void setCurrenthealth(int currenthealth) {

        Currenthealth = currenthealth;
    }
    public void takeDamage(int amount){
            Currenthealth-=amount;
            if(Currenthealth<0){
                Currenthealth=0;
            }
    }
    public boolean isDead(){

        return Currenthealth<=0;
    }
    public void move(double dx, double dy) {
        // Prevent moving out of vertical bounds (simple check)
        double newY = sprite.getY() + dy;
        if (newY >= 0 && newY <= 540) {
            sprite.setY(newY);
        }
        sprite.setX(sprite.getX() + dx);
    }
}
