public class RunGame {
    public static void main(String[] args) {
        // This acts as a wrapper to bypass the JavaFX module check
        BattleArena.main(args);
    }
}